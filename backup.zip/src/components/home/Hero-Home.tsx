"use client";

import React from "react";

const HeroHome: React.FC = () => {
    return (
        <section className="hero-section">
            <div className="container">

                <div className="hero-box">
                    <div className="hero-welcome">
                        <span>WELCOME</span>
                        <p>
                            Beautiful design has the power <br />
                            to captivate audiences.
                        </p>
                    </div>

                    <div className="hero-content">
                        <h1>
                            UNLOCK <br />
                            <span className="outline-text">DIGITAL</span> <br />
                            SUCCESS
                        </h1>

                        <div className="hero-users">
                            <span className="arrow">↗</span>

                            <div className="users">
                                <img src="/assets/img/home/user1.jpg" alt="" />
                                <img src="/assets/img/home/user2.jpg" alt="" />
                                <img src="/assets/img/home/user3.jpg" alt="" />
                            </div>
                        </div>
                    </div>


                    <div className="hero-image">
                        {/* <img src="/assets/img/home/banner.jpg" alt="banner" /> */}
                    </div>

                </div>
            </div>
        </section>
    );
};

export default HeroHome;