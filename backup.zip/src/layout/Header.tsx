"use client";
import Link from "next/link";
import React, { useState } from "react";
import { Container, Row, Col, Nav, NavDropdown } from "react-bootstrap";

const Header: React.FC = () => {
  const [showServices, setShowServices] = useState(false);
  const [showPages, setShowPages] = useState(false);

  return (
    <header className="header">
      <Container fluid className="container p-0 ">
        <Row className="align-items-center g-0"> {/* g-0 removes column gaps */}

          {/* Logo Area */}
          <Col lg={3} xs={6} className="ps-4">
            <div className="logo">
              <Link href="/">
                <img src="/assets/img/logo/Logo360.png" alt="Logo" height="60" />
              </Link>
            </div>
          </Col>

          {/* Navigation Area */}
          <Col lg={6} className="d-none d-lg-block">
            <Nav className="justify-content-center align-items-center">
              <Nav.Link as={Link} href="/" className="nav-item-link">HOME</Nav.Link>

              <NavDropdown
                title="SERVICES"
                id="services-dropdown"
                show={showServices}
                onMouseEnter={() => setShowServices(true)}
                onMouseLeave={() => setShowServices(false)}
              >
                <NavDropdown.Item as={Link} href="/services/web">Web Design</NavDropdown.Item>
              </NavDropdown>

              <Nav.Link as={Link} href="/blogs" className="nav-item-link">BLOGS</Nav.Link>

              <NavDropdown
                title="PAGES"
                id="pages-dropdown"
                show={showPages}
                onMouseEnter={() => setShowPages(true)}
                onMouseLeave={() => setShowPages(false)}
              >
                <NavDropdown.Item as={Link} href="/about">About</NavDropdown.Item>
              </NavDropdown>

              <Nav.Link as={Link} href="/contact" className="nav-item-link">CONTACT</Nav.Link>
            </Nav>
          </Col>

          {/* THE CURVED CTA AREA */}
          <Col lg={3} xs={6} className="cta-col">
            <div className="cta-wrapper">
              <Link href="/get-started" className="hero-button-wrapper">
                <span className="hero-button-text">GET STARTED</span>
                <span className="hero-button-icon">→</span>
              </Link>
            </div>
          </Col>

        </Row>
      </Container>
    </header>
  );
};

export default Header;