import HeroHome from "@/components/home/Hero-Home";
export default function HomePage() {
  return <>
    <HeroHome />
  </>;
}